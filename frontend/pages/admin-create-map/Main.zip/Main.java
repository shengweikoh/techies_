//package ubs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Main {
    public static class Student {
        int id;
        List<Double> homeLocation;
        String alumni;
        String volunteer;

        public Student() {
            homeLocation = new ArrayList<>();
        }
    }

    public static class School {
        String name;
        List<Double> location;
        int maxAllocation;

        public School() {
            location = new ArrayList<>();
        }
    }

    public static class StudentScore {
        Student student;
        double score;
    
        StudentScore(Student student, double score) {
            this.student = student;
            this.score = score;
        }
    }

    private static List<School> schools;
    private static List<Student> students;

    private static String readFile(String fileName) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    private static void parseSchools(String json) {
        schools = new ArrayList<>();
        String schoolsJson = json.split("\"schools\": \\[\\{")[1].split("}],")[0];
        String[] schoolEntries = schoolsJson.split("\\},\\{");
        for (String entry : schoolEntries) {
            School school = new School();
            school.name = parseString(entry, "\"name\": \"", "\"");
            String location = parseString(entry, "\"location\":", "\\]");
            String[] locParts = location.split(",");
            for (String part : locParts) {
                school.location.add(Double.parseDouble(part.trim().replaceAll("[^0-9]", "")));
            }
            school.maxAllocation = Integer.parseInt(parseString(entry, "\"maxAllocation\":", "}").replaceAll("[^0-9]", ""));
            schools.add(school);
        }
    }

    private static void parseStudents(String json) {
        students = new ArrayList<>();
        String studentsJson = json.split("\"students\": \\[\\{")[1];
        String[] studentEntries = studentsJson.split("\\},\\{");

        for (String entry : studentEntries) {
            Student student = new Student();
            student.id = Integer.parseInt(parseString(entry, "\"id\":", ",").replaceAll("[^0-9]", ""));
            String location = parseString(entry, "\"homeLocation\":", "\\]");
            String[] locParts = location.split(",");
            for (String part : locParts) {
                student.homeLocation.add(Double.parseDouble(part.trim().replaceAll("[^0-9]", "")));
            }
            student.alumni = parseString(entry, "\"alumni\": \"", "\"");
            student.volunteer = parseString(entry, "\"volunteer\": \"", "\"");
            students.add(student);
        }
    }

    private static String parseString(String json, String start, String end) {
        if (json.contains(start) && json.split(start).length > 1) {
            return(json.split(start)[1].split(end)[0]);
        } else {
            return(json.split(start)[0].split(end)[0]);
        }
    }

    private static double calculateWeightageScore(School school, Student student) {
        double distance = Math.hypot(school.location.get(0) - student.homeLocation.get(0), school.location.get(1) - student.homeLocation.get(1));
        double distanceScore = 50 * (1 / distance); // Distance inversely related to score
        double alumniScore = student.alumni != null && student.alumni.equals(school.name) ? 30 : 0;
        double volunteerScore = student.volunteer != null && student.volunteer.equals(school.name) ? 20 : 0;
        return distanceScore + alumniScore + volunteerScore;
    }

    private static HashMap<String, List<StudentScore>> allocationMapping () {
        HashMap<String, List<StudentScore>> schoolAllocationMap = new HashMap<>();
        for (School school : schools) {
            List<StudentScore> studentScores = new ArrayList<>();
            for (Student student : students) {
                double score = calculateWeightageScore(school, student);
                studentScores.add(new StudentScore(student, score));
            }
            studentScores.sort((a, b) -> {
                if (Double.compare(b.score, a.score) == 0) {
                    return Integer.compare(a.student.id, b.student.id);
                }
                return Double.compare(b.score, a.score);
            });
            schoolAllocationMap.put(school.name, studentScores);
        }
        return schoolAllocationMap;
    }

    private static TreeMap<String, List<Integer>> allocateStudents(HashMap<String, List<StudentScore>> schoolAllocationMap) {
        TreeMap<String, List<Integer>> allocationResult = new TreeMap<>();
        for (School school : schools) {
            List<StudentScore> sortedScores = schoolAllocationMap.get(school.name);

            // update sortedScores by removing allocated students
            Iterator<StudentScore> sortedScoresIterator = sortedScores.iterator();
            while (sortedScoresIterator.hasNext()) {
                Student student = sortedScoresIterator.next().student;

                if (!students.contains(student)) {
                    sortedScoresIterator.remove();
                }
            }

            List<Integer> allocatedStudents = new ArrayList<>();
            for (int i = 0; i < school.maxAllocation && i < sortedScores.size(); i++) {
                Student student = sortedScores.get(i).student;
                allocatedStudents.add(sortedScores.get(i).student.id);
                students.remove(student);
            }
            allocationResult.put(school.name, allocatedStudents);
        }
        return allocationResult;
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java Main <input_file>");
            return;
        }
        
        String jsonString = readFile(args[0]);

        // Parse JSON manually
        parseSchools(jsonString);
        parseStudents(jsonString);

        HashMap<String, List<StudentScore>> schoolAllocationMap = allocationMapping();
        TreeMap<String, List<Integer>> allocationResult = allocateStudents(schoolAllocationMap);

        try {
            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.append("[\n");
            for (Map.Entry<String, List<Integer>> entry : allocationResult.entrySet()) {
                outputBuilder.append("  {\n     \"" + entry.getKey() + "\": " + entry.getValue().toString() + "\n  },\n");
            }
            if (!allocationResult.isEmpty()) {
                outputBuilder.delete(outputBuilder.length() - 2, outputBuilder.length()); // Remove the last comma
            }
            outputBuilder.append("\n]");
        
            BufferedWriter bw = new BufferedWriter(new FileWriter("output.json"));
            bw.write(outputBuilder.toString());
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
